<?php 
define('APP_NAME','equipment');
define('APP_PATH', './equipment/');
define('APP_DEBUG',TRUE);
define('BIND_MODULE', 'Home'); // 绑定Admin模块到当前入口文件
include "./ThinkPHP/ThinkPHP.php";
 ?>