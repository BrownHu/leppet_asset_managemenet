<?php
namespace Home\Controller;
use Think\Controller;
class QrcodeController  extends Controller {
    
   
    function  index(){
    echo "this is index";

    }
    function  get_mes_by_code($temp){
		vendor("phpqrcode.phpqrcode");
			foreach ($temp as  $value) {
				// 纠错级别：L、M、Q、H
            $level = 'L';
            // 点的大小：1到10,用于手机端4就可以了
            $size = 4;
            $path ="./images/";
            // 生成的文件名
            $filename=time()+rand(0,10000000).'.png';
            $url = $path.$filename;
            $qr_path[]=array('add_time'=>time(),'qr_path'=>$url);
            \QRcode::png($value,$url, $level, $size);//生成
              // \QRcode::png($data, false, $level, $size);//显示 
			}
          	return $qr_path;
    }
   public function testself(){
   	$arr=array('hubing','youyou');
   	$hello=$this->get_mes_by_code($arr);	
   	var_dump($hello);
	   }
}