<?php 
namespace Admin\Model;
use Think\Model;
class CuteModel extends Model{
	protected $tableName = 'user'; 
	function  get(){

		return "why";
	}
}



 ?>