<?php
return array(
	//'配置项'=>'配置值'

	//上传路径
	'UPLOAD_PATH' => __ROOT__.'/Public/e8admin/upload/',
	//权限SESSION名称
	'PERM_SESSION_NAME' => 'perm',

);