<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>乐宠-Excel上传批处理</title>
    <link rel="stylesheet" type="text/css" href="./public/css/uploadify.css">
    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.js"></script>
    <link rel="stylesheet" href="/leepet/Public/CSS/common.css">
   
  
</head>
<body>
<div class="top_div">
<img src="/leepet/Public/logo.png" class='logo'>
    <div  class="for_admin">
        &nbsp; &nbsp; &nbsp; <a href="<?php echo U('Index/index');?>">单条记录传送门</a>&nbsp; &nbsp; &nbsp;
    </div>
</div>
<div style="width: 400px;height: 200px;margin: auto auto;background: #ffffff;text-align: center;margin-top: -100px;border: 1px solid #e7e7e7">
    <div style="width: 165px;height: 96px;position: absolute">
        <div class="tou"></div>
        <div id="left_hand" class="initial_left_hand"></div>
        <div id="right_hand" class="initial_right_hand"></div>
    </div>
<form action="<?php echo U('ExcelAbout/in_operate');?>" method='post' enctype="multipart/form-data">
         <p style="padding: 50px 0px 0px 120px;position: relative;">
        <input id="file_upload" type="file" name="excel"/>
    </p>
     <p style="padding: 90px 0px 0px 0px;position: relative;">
       <input type="submit" value="开始excel引导">
    </p>
	</form>
</body>
</div>
<div style="position: fixed;bottom: 0px;text-align: center;width: 100%;">
    Copyright ©2015 <a style="margin-left: 10px;color: #000000;text-decoration: underline" href="http://www.leepet.com/">http://www.leepet.com</a> <a href="<?php echo U('/Admin/index/index');?>">管理后台</a>
</div>
</body>
</html>