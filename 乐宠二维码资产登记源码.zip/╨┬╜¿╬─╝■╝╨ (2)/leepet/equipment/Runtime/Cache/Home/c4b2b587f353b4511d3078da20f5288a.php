<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>乐宠资产登记管理员登录</title>
    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.js"></script>
    <link rel="stylesheet" href="/leepet/Public/CSS/common.css">
    
   
</head>
<body>
<div class="top_div"><img src="/leepet/Public/logo.png" class='logo'></div>
<div style="width: 400px;height: 200px;margin: auto auto;background: #ffffff;text-align: center;margin-top: -100px;border: 1px solid #e7e7e7">
 <div class='wel' >登录到乐宠资产管理系统</div>
<form action="<?php echo U('login/login');?>" method="post">
    <p style="padding: 30px 0px 10px 0px;position: relative;">
        <span class="u_logo"></span>
        <input class="ipt" type="text"   name="name" placeholder="管理员账号" />
    </p>
    <p style="position: relative;">
        <span class="p_logo"></span>
        <input  class="ipt" type="password"  name="pass"  placeholder="管理员密码">
    </p>

    <div style="height: 50px;line-height: 50px;margin-top: 30px;border-top: 1px solid #e7e7e7;">
        <p style="margin: 0px 35px 20px 45px;">
           <span style="float: right">
               <input type="submit" style="background: #008ead;padding: 7px 10px;border-radius: 4px;border: 1px solid #1a7598;color: #FFF;font-weight: bold;" value="登录" />
           </span>
        </p>
    </div>
</form>
</div>


</body>
</html>