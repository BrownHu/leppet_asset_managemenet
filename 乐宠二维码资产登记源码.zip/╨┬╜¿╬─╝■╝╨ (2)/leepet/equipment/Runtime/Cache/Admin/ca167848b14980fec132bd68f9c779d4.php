<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;}            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 80px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">乐宠二维码资产登记 </div>
            </div>
        </div>
    


</body></html>