<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>资产记录展示</title>
    <link rel="stylesheet" href="/leepet/Public/CSS/buttons.css">
    <link rel="stylesheet" href="/leepet/Public/CSS/common.css">
    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.js"></script>
<style>
    .for_single{
        left: 45%;
    }


</style>
  
</head>
<body>
<div class="for_single"  id="for_print">
    <img src="/leepet<?php echo ($message["qr_path"]); ?>" alt="test_for_single"  class="image_once">
</div></div>
<div class="for_print_once">
 <!-- <div   id="div2"><img src="__IMAGE__<?php echo ($url); ?>" id="src_deal"></div> -->
<a href="javascript:printHTML('#for_print')" target="_self" class="button button-glow button-rounded button-raised button-primary" >打印</a>

<script language="javascript">
function printHTML(page)
{
var bodyHTML=window.document.body.innerHTML;
window.document.body.innerHTML=$(page).html();
window.print();
window.document.body.innerHTML=bodyHTML;
}
</script>

</div>


</body>
</html>