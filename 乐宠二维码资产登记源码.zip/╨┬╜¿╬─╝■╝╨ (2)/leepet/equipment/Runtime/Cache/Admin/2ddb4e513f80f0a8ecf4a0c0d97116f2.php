<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
  <head>
  	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>e8通用后台</title>
    
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/leepet/Public/e8admin/default/lib/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="/leepet/Public/e8admin/default/lib/font-awesome/css/font-awesome.min.css">
    
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!-- e8 style -->
    <link rel="stylesheet" href="/leepet/Public/e8admin/default/css/common.css">
    <link rel="stylesheet" href="/leepet/Public/e8admin/default/css/main.css">
    
  </head>
  
  <body>
  
  	<div class="topbar">
    	
        <!-- 面包屑 -->
        

        <div class="topbar-search">
        	<form class="form-inline" role="form">
            	<div class="form-group">
            		<label class="sr-only" for="exampleInputEmail2">Email address</label>
            		<input type="email" class="form-control input-sm" id="exampleInputEmail2" placeholder="Enter email">
                    
                    <i class="fa fa-search color-gray"></i>
          		</div>
            </form>
        </div>
    </div><!-- /.topbar -->
    
    <div class="page-content">
    
        <div class="page-header col-sm-12">
        	<h1>个人密码修改</h1>
        </div>
        
        <div class="col-sm-12">
			<div class="tabbable">
				<ul class="nav nav-tabs">
					<li class="active">
						<a  href="#">修改密码</a>
					</li>
				</ul>
				
				<div class="tab-content">
                
					<div class="tab-pane in active">
						<p class="title background-blue">基本属性</p>
                        <form action="/leepet/admin.php/Person/pwd" method="post" >
                            <input type="hidden" name="id" value="<?php echo ($person["id"]); ?>" />
                            <input type="hidden" name="mw" value="<?php echo ($person["mw"]); ?>" />
                            <table width="100%" class="table-form">
                                <tbody>
                                    <tr>
                                        <th width="100">用户名</th>
                                        <td>
                                            <input type="text" class="form-control input-sm wid-3"  value="<?php echo ($person["username"]); ?>" readonly/>
                                        </td>
                                    </tr>
                                     <tr>
                                        <th>旧密码</th>
                                        <td>
                                            <input type="password" name="oldpwd" class="form-control input-sm wid-3" value=""/>
                                            <span class="e8-danger msg" id="danger-pwd"></span>
                                            <span class="e8-prompt msg" id="prompt-pwd"></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>新密码</th>
                                        <td>
                                            <input type="password" class="form-control input-sm wid-3"  name="password" value=""/>
                                        </td>
                                    </tr>
                                     <tr>
                                        <th>确认新密码</th>
                                        <td>
                                            <input type="password" class="form-control input-sm wid-3" 
                                            name="truepassword" value=""/>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                            <div style="width:100%;height:60px;"></div>
                            <div class="admin-add">
                                <button class="btn btn-primary btn-sm" type="submit">修改</button>
                            </div>
                        </form>
					</div>
				</div>
			</div>
		</div><!-- /span -->
        
    </div><!-- /.page-content -->
    
  
    <!-- jQuery文件 -->
	<script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
	<script src="/leepet/Public/e8admin/default/lib/bootstrap/bootstrap.min.js"></script>
    <!--  -->
	<script src="/leepet/Public/e8admin/default/js/e8.js"></script>
    
    <script>
    $(document).ready(function() { 
        var APP = "/leepet/admin.php";

        // Ajax验证旧密码是否正确
        $("input[name='oldpwd']").blur(function(){
            var val = $(this).val();
            $.ajax({
                type: "get",
                url: APP + "/Person/checkpwd/id/" + <?php echo ($person["id"]); ?> + "/val/" + val,
                dataType: 'json',
                success: function(data){
                    $(".msg").html("");
                    if (data.status == 1){
                        $("#prompt-pwd").html(data.msg);
                    }else{
                        $("#danger-pwd").html(data.msg);
                    }
                },
                error: function(request){
                    alert("验证失败!");
                }
            });
        });

    });
    </script>

  </body>
</html>