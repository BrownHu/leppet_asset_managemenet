<?php 
define('APP_NAME','equipment');
define('APP_PATH', './equipment/');
define('APP_DEBUG',TRUE);
define('IMAGE','./images/');
// define('BIND_MODULE', "home");
// define('BIND_CONTROLLER',"login");
// define('BIND_ACTION', "login");
include "./ThinkPHP/ThinkPHP.php";
 ?>