/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : leepet

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-08-11 14:46:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for leepet_asset
-- ----------------------------
DROP TABLE IF EXISTS `leepet_asset`;
CREATE TABLE `leepet_asset` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(255) NOT NULL,
  `add_time` bigint(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `user_part_id` int(11) NOT NULL,
  `qr_path` varchar(255) NOT NULL DEFAULT '生成错误，请单独重试',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for leepet_branch
-- ----------------------------
DROP TABLE IF EXISTS `leepet_branch`;
CREATE TABLE `leepet_branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for leepet_staff
-- ----------------------------
DROP TABLE IF EXISTS `leepet_staff`;
CREATE TABLE `leepet_staff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for leepet_user
-- ----------------------------
DROP TABLE IF EXISTS `leepet_user`;
CREATE TABLE `leepet_user` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(12) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '管理员登录账号',
  `user_pass` varchar(255) DEFAULT NULL,
  `user_nick` varchar(8) DEFAULT '帅气的未命名用户',
  `user_intro` varchar(15) DEFAULT '这个人很懒，什么都没留下',
  `last_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
