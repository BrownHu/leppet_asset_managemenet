<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>乐宠资产登记</title>
    <link rel="stylesheet" href="/leepet/Public/CSS/buttons.css">
    <link rel="stylesheet" href="/leepet/Public/CSS/common.css">
    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.js"></script>

  
</head>
<body>
<div class="for_tips">  扫码验证当前二维码信息是否为: <?php echo ($qw_info); ?></div>

<div class="top_div"><img src="/leepet/Public/logo.png" class='logo'>
<div class="for_single"  id="for_print">
    <img src="/leepet/images/<?php echo ($url); ?>" alt="test_for_single">
</div></div>
<div class="for_print_once">
 <!-- <div   id="div2"><img src="/leepet/images/<?php echo ($url); ?>" id="src_deal"></div> -->
<a href="javascript:printHTML('#for_print')" target="_self" class="button button-glow button-rounded button-raised button-primary" >打印</a>

<script language="javascript">
function printHTML(page)
{
var bodyHTML=window.document.body.innerHTML;
window.document.body.innerHTML=$(page).html();
window.print();
window.document.body.innerHTML=bodyHTML;
}
</script>

</div>

<div style="position: fixed;bottom: 0px;text-align: center;width: 100%;">
    Copyright ©2015 <a style="margin-left: 10px;color: #000000;text-decoration: underline" href="http://www.leepet.com">http://www.leepet.com</a>
</div>
</body>
</html>