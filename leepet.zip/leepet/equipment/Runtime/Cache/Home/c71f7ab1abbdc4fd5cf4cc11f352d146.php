<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>乐宠-单资产号测试页</title>
    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.js"></script>
    <script>
    </script>
<link rel="stylesheet" href="/leepet/Public/CSS/common.css">
  
</head>
<body>
<div class="top_div">
<img src="/leepet/Public/logo.png" class='logo'>
    <div  class="for_admin">
    <a href="<?php echo U('ExcelAbout/index');?>"> 传送门</a> &nbsp;&nbsp;&nbsp;
        当前用户: &nbsp;&nbsp;<?php echo ($cur_user); ?> &nbsp; &nbsp; &nbsp; <a href="<?php echo U('Login/log_off');?>">注销</a>
    </div>
</div>
<!-- <div style="width: 400px;height: 200px;margin: auto auto;background: #ffffff;text-align: center;margin-top: -100px;border: 1px solid #e7e7e7">
    <div style="width: 165px;height: 96px;position: absolute">
        <div class="tou"></div>
        <div id="left_hand" class="initial_left_hand"></div>
        <div id="right_hand" class="initial_right_hand"></div>
    </div>
erewr
</div> -->

<div style="position: fixed;bottom: 0px;text-align: center;width: 100%;">
    Copyright ©2015 <a style="margin-left: 10px;color: #000000;text-decoration: underline" href="http://www.leepet.com/">http://www.leepet.com</a>
</div>
</body>
</html>