<?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE'=>'mysql',
	'DB_NAME'=>'leepet',
	'DB_PORT'=>3306,
	'DB_DEBUG'=>true,
	'DB_USER'=>'root',
	'DB_PREFIX'=>'leepet_',
	'DB_PWD'=>'hubing',
	'DB_CHARSET'=>'utf8',
	'URL_HTML_SUFFIX'=>'html',
);