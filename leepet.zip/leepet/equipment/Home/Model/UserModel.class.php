<?php 
		namespace Home\Model;
		use Think\Model;
		class UserModel extends Model{
			 function   login($map){
				$info=$this->where($map)->find()?true :false;
				return $info;
			}
			function  say($mes){
				echo $mes;
			}

		}

 ?>