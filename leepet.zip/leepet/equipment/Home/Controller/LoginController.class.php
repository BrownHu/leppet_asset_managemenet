<?php
	namespace Home\Controller;
	header('Content-type:text/html;charset=utf-8');
	use Think\Controller;
	class LoginController extends Controller{
		public function login(){
			if (IS_POST) {
				$map['user_name']=I('name');
				$map['user_pass']=I('pass','','md5');
				$temp=D('user');
				$info=$temp->login($map);
				if ($info) {
					F('log_sta',1);
					$nick=$this->get_user_nickname(I('name'));
					F('cur_user',$nick);
					$this->success("login in",'../index/index');
				}else $this->error('sorry for login fail');
			}else

			$this->display();
		}
		public function  log_off(){
			F('log_sta',null);
			F('cur_user',null);
			$this->success('status changes','../Index/index');
			// $this->redirect('Index/index');
		}
		public function  get_user_nickname($temp){
		 return D('user')->where("user_name='$temp'")->getfield('user_nick') ;
		}
	}

 ?>